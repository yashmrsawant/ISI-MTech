#ifndef SOLUTION_H
#define SOLUTION_H

#include "gnuplot.h"

void solution1(int* numbers_p, int size);
void solution2(int* numbers_p, int size);
void solution3(int* numbers_p, int size);
void solution4(int* numbers_p, int size);
void solution5(int* numbers_p, int size);
#endif // SOLUTION_H
