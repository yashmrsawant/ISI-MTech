###Assignment 1 - Yash M Sawant 
##CS 1614
##
#
#There is 'main.cpp' file which is the main cpp file for the generating data.dat file.
#There is also a final_application.exe to generate data.dat file.
#
#data.dat contains 1st column 'size', 2nd column 'heapsort_iterative', 3rd column 'heapsort_recursive', 4th column #'mergesort-iterative', 5th column 'mergesort-recursive', 6th column 'quicksort-iterative', 7th column 'quicksort-#recursive'.
#
#There is 'plot' file which is the gnuplot command file for generating sol_1, sol_2, sol_3, sol_4, sol_5
#
#Also i was able to check it windows platform, so gnuplot has to be set on PATH env
#
##All the graph is in X - axis as size of the input and Y - axis is time in usec
###sol_1 is recursive mergesort vs iterative mergesort
###sol_2 is recursive heapsort vs iterative heapsort
###sol_3 is recursive quicksort vs iterative quicksort
###sol_4 is recursive mergesort vs recursive heapsort vs recursive quicksort
###sol_5 is iterative mergesort vs iterative heapsort vs iterative quicksort
################################################################################################